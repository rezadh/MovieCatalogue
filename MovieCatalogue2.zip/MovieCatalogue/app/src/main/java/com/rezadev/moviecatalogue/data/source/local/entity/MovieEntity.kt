package com.rezadev.moviecatalogue.data.source.local.entity

data class MovieEntity (
    val movieId: Int = 0,
    val title: String = "",
    val overview: String = "",
    val releaseDate: String = "",
    val director: String = "",
    val genre: String = "",
    val imagePath: String = ""
)