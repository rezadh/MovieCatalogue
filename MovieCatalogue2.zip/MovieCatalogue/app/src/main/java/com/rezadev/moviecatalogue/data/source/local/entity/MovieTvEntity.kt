package com.rezadev.moviecatalogue.data.source.local.entity

data class MovieTvEntity (
    val movieTvId: Int = 0,
    val title: String = "",
    val overview: String = "",
    val releaseDate: String = "",
    val creator: String = "",
    val genre: String = "",
    val imagePath: String = ""
)